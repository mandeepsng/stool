﻿<?php

/*
 * @author Balaji
 * @name: Rainbow PHP Framework
 * @copyright © 2018 ProThemes.Biz
 *
 */

header('HTTP/1.1 404 Not Found', true, 404);

die("Page Not Found!");

?>