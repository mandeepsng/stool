<?php

defined('APP_NAME') or die(header('HTTP/1.0 403 Forbidden'));

/*
 * @author Balaji
 * @name: Rainbow PHP Framework
 * @copyright � 2018 ProThemes.Biz
 *
 */

$pageTitle = 'PHP Info Viewer';
$subTitle = 'PHP Information';
$fullLayout = 1;

?>